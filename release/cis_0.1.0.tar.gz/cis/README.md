# cis

The `cis` package offers classic and bootstrap confidence intervals for the following parameters:

- The population mean

## Installation

From CRAN:
``` r
install.packages("cis")
```

Latest version from github:
``` r
# library(devtools)
install_github("mayer79/cis")
```

## Teaser

``` r
library(cis)
```

