library(testthat)
library(confintr)

test_check("confintr")
