# confintr 0.1.1

- Added confidence intervals for the odds ratio via stats::fisher.test.

- Fixed wrong VignetteIndexEntry.

# confintr 0.1.0

This is the initial CRAN release.
